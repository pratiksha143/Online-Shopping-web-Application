import { RemoveduplicatePipe } from './removeduplicate.pipe';

describe('RemoveduplicatePipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveduplicatePipe();
    expect(pipe).toBeTruthy();
  });
});
