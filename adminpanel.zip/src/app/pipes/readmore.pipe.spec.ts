import { ReadmorePipe } from './readmore.pipe';

describe('ReadmorePipe', () => {
  it('create an instance', () => {
    const pipe = new ReadmorePipe();
    expect(pipe).toBeTruthy();
  });
});
